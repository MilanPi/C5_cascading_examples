/**
  ******************************************************************************
  * file           : main.c
  * brief          : Main program body
  *                  Calls target system initialization then loop in main.
  ******************************************************************************
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdio.h>

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define RX_TIMEOUT 10000U
#define TX_TIMEOUT 1000U
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
hal_uart_handle_t *pUART;
/* Private functions prototype -----------------------------------------------*/
int __io_putchar(int ch)
{
  if (HAL_UART_Transmit(pUART, (uint8_t *)&ch, 1U, TX_TIMEOUT) == HAL_OK)
  {
    return ch;
  }
  else
  {
    return EOF;
  }
} 

int __io_getchar(void) 
{
  uint8_t ch = 0;

  LL_USART_ClearFlag_ORE(USART2);

  if (HAL_UART_Receive(pUART, &ch, 1U, RX_TIMEOUT) != HAL_OK)
  {
    return EOF;
  }

  return (int8_t)ch;
}
/**
  * brief:  The application entry point.
  * retval: none but we specify int to comply with C99 standard
  */
int main(void)
{
  pUART = mx_usart2_hal_uart_gethandle();

  /** System Init: this code placed in targets folder initializes your system.
    * It calls the initialization (and sets the initial configuration) of the peripherals.
    * You can use STM32CubeMX to generate and call this code or not in this project.
    * It also contains the HAL initialization and the initial clock configuration.
    */
  if (mx_system_init() != SYSTEM_OK)
  {
    return (-1);
  }
  else
  {
    /*
      * You can start your application code here
      */
    char buff[100];
    setvbuf(stdin, NULL, _IONBF, 0); //TO HANDLE INPUT BUFFER WHEN USING SCANF/COUT
    while (1) 
    {
      scanf("%s",buff);
      printf("Echo: %s\n", buff);
    }
  }
} /* end main */

