/**
  ******************************************************************************
  * file           : main.c
  * brief          : Main program body
  *                  Calls target system initialization then loop in main.
  ******************************************************************************
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define TX_TIMEOUT 1000U
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint8_t  rx_complete = 0; // indicates complete reception on RX line
uint32_t rx_cnt = 0;      // holds the count of received characters
uint8_t flag = 0;         // to distinguish between "Trasfer complete" and "Idle" event.
hal_uart_handle_t *pUART;
char buff[100] = {0};
/* Private functions prototype -----------------------------------------------*/
void rx_complete_cb(hal_uart_handle_t *huart, uint32_t size_byte,
                                       hal_uart_rx_event_types_t rx_event)
{
  if( rx_event == HAL_UART_RX_EVENT_IDLE )
  {
    rx_complete = 1;
    rx_cnt = size_byte;  
    flag = 1;  
  }  

  if(rx_event == HAL_UART_RX_EVENT_TC)
  {
    rx_complete = 1;
    rx_cnt = size_byte;  
    flag = 2;
  }
}

void print_char_count(uint8_t _nb, uint8_t _flag)
{
  uint8_t nb[2];

  if(_flag == 1) // reception upon Idle event
  {
    HAL_UART_Transmit(pUART, (uint8_t *)"IDLE ", 5, TX_TIMEOUT);
  }
  else if (_flag == 2) // reception upon Count reached event
  {
    HAL_UART_Transmit(pUART, (uint8_t *)"COUNT ", 6, TX_TIMEOUT);
  }
  // Converts dec. number to characters
  nb[0] = (_nb / 10) + 0x30;
  nb[1] = (_nb % 10) + 0x30;
  HAL_UART_Transmit(pUART, nb, 2, TX_TIMEOUT);
  HAL_UART_Transmit(pUART, (uint8_t *)": ", 2, TX_TIMEOUT);
}
/**
  * brief:  The application entry point.
  * retval: none but we specify int to comply with C99 standard
  */
int main(void)
{
  /** System Init: this code placed in targets folder initializes your system.
    * It calls the initialization (and sets the initial configuration) of the peripherals.
    * You can use STM32CubeMX to generate and call this code or not in this project.
    * It also contains the HAL initialization and the initial clock configuration.
    */
  if (mx_system_init() != SYSTEM_OK)
  {
    return (-1);
  }
  else
  {
    /*
      * You can start your application code here
      */
    pUART = mx_usart2_hal_uart_gethandle();

    if( HAL_UART_RegisterRxCpltCallback(pUART, rx_complete_cb) != HAL_OK)
    {
      // Error handler
      __asm("BKPT");      
    }

    while (1) 
    {
      LL_USART_ClearFlag_ORE(USART2); // To recover after exceeding buffer count during reception
      HAL_UART_ReceiveToIdle_IT(pUART, buff, sizeof(buff));

      while(rx_complete == 0);
      
      rx_complete = 0;
      print_char_count(rx_cnt - 1, flag);
      flag = 0;
      HAL_UART_Transmit(pUART, buff, rx_cnt, TX_TIMEOUT);
    }
  }
} /* end main */

